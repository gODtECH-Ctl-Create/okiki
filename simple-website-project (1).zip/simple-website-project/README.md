# BrightPath Simple Website

A beginner-friendly static website built with HTML, CSS, and JavaScript.

## Files

- `index.html` — Home, About, Services, and Contact sections.
- `signup.html` — Demo sign-up form.
- `thank-you.html` — Confirmation page after the demo form is submitted.
- `css/style.css` — Website styling and responsive/mobile layout.
- `js/script.js` — Mobile menu, footer year, demo contact form, and demo sign-up redirect.

## Run in Visual Studio Code

1. Extract the ZIP file.
2. Open Visual Studio Code.
3. Select **File → Open Folder** and choose the `simple-website-project` folder.
4. Install the **Live Server** extension by Ritwick Dey from the Extensions panel if you do not already have it.
5. Right-click `index.html` and choose **Open with Live Server**.
6. Test the Home, About, Services, Contact, and Sign Up links. Submit the sign-up form to reach `thank-you.html`.

## Important

This is a front-end learning project. The sign-up page does not save user information or create accounts, and the contact form does not send emails. Real accounts and sign-in need a secure authentication service or backend. Never collect real passwords in a front-end-only demo.

The About section uses a remote image, so an internet connection is needed for that picture to load.
